# Momentum — Android app project

This is a native Android WebView wrapper of the Momentum daily productivity dashboard.
The dashboard is bundled offline and includes unlimited daily tracking, habits,
focus timer, sleep logs, goals and analytics. Records persist on the device in the
app's WebView local storage. Export Backup opens an Android save-file dialog;
Import Backup opens the Android document picker.

## Build and install an APK
1. On a computer, install Android Studio (latest stable) and open this project folder.
2. Let Android Studio install/sync the Android SDK (API 35) and Gradle plugin.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Locate `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your Android device and install it. Android may ask you to
   allow installation from the file manager you are using.

No internet permission is requested by the app. The Gradle build itself requires
internet the first time to fetch Android development dependencies.

This ZIP contains Android Studio source, NOT a prebuilt APK. Existing records
in your separately opened HTML file do not move automatically: use Export Backup
there, then Import Backup in the installed Android app.
